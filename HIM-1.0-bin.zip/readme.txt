
Homolog Interaction Mapping tool
Version 1.0


Steps:
1 - Move the contents of cytoscape_plugins to the Cytoscape Plugin directory
2 - Make sure you have a Postgresql database running with STRING on it.
3 - Create biobricks in a partsregistry website
4 - Enter biobricks in the parts list in HIM.
5 - Enter the aminoacid sequences in STRING, blast them, and assign the resulting STRING ID to the part in HIM.
6 - Follow rest of the steps through the program.


For future versions, I will add the ability to add custom aminoacid sequences to the parts list. 
Hopefully it will also be possible to automate step 5 using an online sequence blast service.


Contact

Jelmer Cnossen: j.cnossen at gmail
